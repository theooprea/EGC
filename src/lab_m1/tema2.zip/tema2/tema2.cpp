#include "lab_m1/tema2/tema2.h"

#include <vector>
#include <string>
#include <iostream>

#include "lab_m1/tema2/tema2_transform3D.h"

using namespace std;
using namespace m1;


/*
 *  To find out more about `FrameStart`, `Update`, `FrameEnd`
 *  and the order in which they are called, see `world.cpp`.
 */


Tema2::Tema2()
{
}


Tema2::~Tema2()
{
}

void Tema2::Init()
{
    playerAngleLeftRight = M_PI;
    playerAngleUpDown = 0;

    timeSinceStart = 0;
    lastShot = 0;

    generateLabirinth();

    playerX = starting_pos_row * 4 - 20;
    playerY = 2;
    playerZ = -20;

    for (int i = 0; i < labirinth_rows; i++) {
        for (int j = 0; j < labirinth_cols; j++) {
            cout << labirinth[i][j] << " ";
        }
        cout << endl;
    }

    renderCameraTarget = false;

    camera1 = new implemented::CameraTema2();
    camera1->Set(glm::vec3(playerX, playerY + 0.1, playerZ), glm::vec3(playerX, playerY + 0.1, playerZ - 3.5), glm::vec3(0, 1, 0));

    camera2 = new implemented::CameraTema2();
    camera2->Set(glm::vec3(playerX, playerY + 1.5, playerZ + 2.5), glm::vec3(playerX, playerY - 1, playerZ - 2.5), glm::vec3(0, 1, 0));
    camera2->distanceToTarget = distance(glm::vec3(playerX, playerY + 1.5, playerZ + 2.5), glm::vec3(playerX, playerY + 0.075, playerZ));

    cout << camera2->distanceToTarget << endl;

    camera1->RotateFirstPerson_OY(playerAngleLeftRight);

    camera2->RotateThirdPerson_OY(playerAngleLeftRight);

    camera = camera2;

    {
        Mesh* mesh = new Mesh("box");
        mesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
        meshes[mesh->GetMeshID()] = mesh;
    }

    {
        Mesh* mesh = new Mesh("sphere");
        mesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "sphere.obj");
        meshes[mesh->GetMeshID()] = mesh;
    }

    {
        Shader* shader = new Shader("LabShader");
        shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "lab7", "shaders", "VertexShader.glsl"), GL_VERTEX_SHADER);
        shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "lab7", "shaders", "FragmentShader.glsl"), GL_FRAGMENT_SHADER);
        shader->CreateAndLink();
        shaders[shader->GetName()] = shader;
    }

    {
        lightPosition = glm::vec3(0, 5, 0);
        materialShininess = 30;
        materialKd = 0.5;
        materialKs = 0.5;
    }

    field_of_view = 60;
    projection_type = 0;
    projectionMatrix = glm::perspective(RADIANS(field_of_view), window->props.aspectRatio, 0.01f, 200.0f);

}


void Tema2::FrameStart()
{
    // Clears the color buffer (using the previously set color) and depth buffer
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::ivec2 resolution = window->GetResolution();
    // Sets the screen area where to draw
    glViewport(0, 0, resolution.x, resolution.y);
}


void Tema2::Update(float deltaTimeSeconds)
{
    timeSinceStart += deltaTimeSeconds;

    {
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, lightPosition);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(0.1f));
        RenderMesh(meshes["sphere"], shaders["Simple"], modelMatrix);
    }

    /*{
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 1, 0));
        modelMatrix = glm::rotate(modelMatrix, RADIANS(45.0f), glm::vec3(0, 1, 0));

        RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);
    }

    {
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(2, 0.5f, 0));
        modelMatrix = glm::rotate(modelMatrix, RADIANS(60.0f), glm::vec3(1, 0, 0));
        RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);
    }

    {
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, glm::vec3(-2, 0.5f, 0));
        RenderMesh(meshes["box"], shaders["Simple"], modelMatrix);
    }*/

    // Labirinth Walls
    {
        for (int i = 0; i < labirinth_rows; i++) {
            for (int j = 0; j < labirinth_cols; j++) {
                if (labirinth[i][j] == 1) {
                    glm::mat4 modelMatrix = glm::mat4(1);
                    modelMatrix *= transform3DTema2::Translate(i * 4 - 20, 1, j * 4 - 20);
                    modelMatrix *= transform3DTema2::Scale(4, 2, 4);
                    RenderSimpleMesh(meshes["box"], shaders["LabShader"], modelMatrix, glm::vec3(0.5, 0.5, 0.5));
                }
            }
        }
    }
    
    // Player
    {
        // Torso
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix *= transform3DTema2::Translate(playerX, playerY - 0.5, playerZ);
        modelMatrix *= transform3DTema2::RotateOY(playerAngleLeftRight);
        modelMatrix *= transform3DTema2::Scale(0.5, 0.8, 0.3);
        RenderSimpleMesh(meshes["box"], shaders["LabShader"], modelMatrix, glm::vec3(0.4, 0.7, 0.7));

        // Legs
        modelMatrix = glm::mat4(1);
        modelMatrix *= transform3DTema2::Translate(playerX + 0.13 * cos(playerAngleLeftRight), playerY - 1.325, playerZ - 0.13 * sin(playerAngleLeftRight));
        modelMatrix *= transform3DTema2::RotateOY(playerAngleLeftRight);
        modelMatrix *= transform3DTema2::Scale(0.23, 0.8, 0.3);
        RenderSimpleMesh(meshes["box"], shaders["LabShader"], modelMatrix, glm::vec3(0.25, 0.3, 0.7));

        modelMatrix = glm::mat4(1);
        modelMatrix *= transform3DTema2::Translate(playerX - 0.13 * cos(playerAngleLeftRight), playerY - 1.325, playerZ + 0.13 * sin(playerAngleLeftRight));
        modelMatrix *= transform3DTema2::RotateOY(playerAngleLeftRight);
        modelMatrix *= transform3DTema2::Scale(0.23, 0.8, 0.3);
        RenderSimpleMesh(meshes["box"], shaders["LabShader"], modelMatrix, glm::vec3(0.25, 0.3, 0.7));

        if (camera == camera2) {
            // Head
            modelMatrix = glm::mat4(1);
            modelMatrix *= transform3DTema2::Translate(playerX, playerY + 0.075, playerZ);
            modelMatrix *= transform3DTema2::RotateOY(playerAngleLeftRight);
            modelMatrix *= transform3DTema2::Scale(0.3, 0.3, 0.3);
            RenderSimpleMesh(meshes["box"], shaders["LabShader"], modelMatrix, glm::vec3(0.97, 0.93, 0.88));
        }
    
        // Arms
        modelMatrix = glm::mat4(1);
        modelMatrix *= transform3DTema2::Translate(playerX + 0.38 * cos(playerAngleLeftRight), playerY - 0.34, playerZ - 0.38 * sin(playerAngleLeftRight));
        modelMatrix *= transform3DTema2::RotateOY(playerAngleLeftRight);
        modelMatrix *= transform3DTema2::Scale(0.23, 0.48, 0.3);
        RenderSimpleMesh(meshes["box"], shaders["LabShader"], modelMatrix, glm::vec3(0.4, 0.7, 0.7));

        modelMatrix = glm::mat4(1);
        modelMatrix *= transform3DTema2::Translate(playerX - 0.38 * cos(playerAngleLeftRight), playerY - 0.34, playerZ + 0.38 * sin(playerAngleLeftRight));
        modelMatrix *= transform3DTema2::RotateOY(playerAngleLeftRight);
        modelMatrix *= transform3DTema2::Scale(0.23, 0.48, 0.3);
        RenderSimpleMesh(meshes["box"], shaders["LabShader"], modelMatrix, glm::vec3(0.4, 0.7, 0.7));

        // Forearms
        modelMatrix = glm::mat4(1);
        modelMatrix *= transform3DTema2::Translate(playerX + 0.38 * cos(playerAngleLeftRight), playerY - 0.745, playerZ - 0.38 * sin(playerAngleLeftRight));
        modelMatrix *= transform3DTema2::RotateOY(playerAngleLeftRight);
        modelMatrix *= transform3DTema2::Scale(0.23, 0.3, 0.3);
        RenderSimpleMesh(meshes["box"], shaders["LabShader"], modelMatrix, glm::vec3(0.97, 0.93, 0.88));

        modelMatrix = glm::mat4(1);
        modelMatrix *= transform3DTema2::Translate(playerX - 0.38 * cos(playerAngleLeftRight), playerY - 0.745, playerZ + 0.38 * sin(playerAngleLeftRight));
        modelMatrix *= transform3DTema2::RotateOY(playerAngleLeftRight);
        modelMatrix *= transform3DTema2::Scale(0.23, 0.3, 0.3);
        RenderSimpleMesh(meshes["box"], shaders["LabShader"], modelMatrix, glm::vec3(0.97, 0.93, 0.88));
    }

    // Projectiles
    {
        for (int i = 0; i < projectiles.size(); i++) {
            Projectile* projectile = &projectiles[i];

            projectile->projectile_position.x -= 5 * deltaTimeSeconds * sin(projectile->angleLeftRight);
            projectile->projectile_position.z -= 5 * deltaTimeSeconds * cos(projectile->angleLeftRight);
            projectile->projectile_position.y += 5 * deltaTimeSeconds * sin(projectile->angleUpDown);

            projectile->distance_travelled += sqrt((5 * deltaTimeSeconds * sin(projectile->angleLeftRight)) * (5 * deltaTimeSeconds * sin(projectile->angleLeftRight))
                + (5 * deltaTimeSeconds * cos(projectile->angleLeftRight)) * (5 * deltaTimeSeconds * cos(projectile->angleLeftRight))
                + (5 * deltaTimeSeconds * sin(projectile->angleUpDown)) * (5 * deltaTimeSeconds * sin(projectile->angleUpDown)));

            if (projectile->distance_travelled >= 8) {
                projectiles.erase(projectiles.begin() + i);
                i--;
                continue;
            }

            glm::mat4 modelMatrix = glm::mat4(1);
            modelMatrix *= transform3DTema2::Translate(projectile->projectile_position.x, projectile->projectile_position.y, projectile->projectile_position.z);
            modelMatrix *= transform3DTema2::Scale(0.1, 0.1, 0.1);
            RenderSimpleMesh(meshes["sphere"], shaders["LabShader"], modelMatrix, glm::vec3(0.9, 0.9, 0.9));
        }
    }

    if (renderCameraTarget)
    {
        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, camera->GetTargetPosition());
        modelMatrix = glm::scale(modelMatrix, glm::vec3(0.1f));
        RenderMesh(meshes["sphere"], shaders["VertexNormal"], modelMatrix);
    }
}


void Tema2::FrameEnd()
{
    DrawCoordinateSystem(camera->GetViewMatrix(), projectionMatrix);
}


void Tema2::RenderMesh(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix)
{
    if (!mesh || !shader || !shader->program)
        return;

    // Render an object using the specified shader and the specified position
    shader->Use();
    glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
    glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
    glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

    mesh->Render();
}

void Tema2::RenderSimpleMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, const glm::vec3& color)
{
    if (!mesh || !shader || !shader->GetProgramID())
        return;

    // Render an object using the specified shader and the specified position
    glUseProgram(shader->program);

    // Set shader uniforms for light & material properties
    // TODO(student): Set light position uniform
    int light_location = glGetUniformLocation(shader->program, "light_position");
    glUniform3fv(light_location, 1, glm::value_ptr(lightPosition));

    glm::vec3 eyePosition = camera->position;
    // TODO(student): Set eye position (camera position) uniform

    int eye_location = glGetUniformLocation(shader->program, "eye_position");
    glUniform3fv(eye_location, 1, glm::value_ptr(eyePosition));

    // TODO(student): Set material property uniforms (shininess, kd, ks, object color)
    int material_locations = glGetUniformLocation(shader->program, "material_shininess");
    glUniform1i(material_locations, materialShininess);

    int material_kd_location = glGetUniformLocation(shader->program, "material_kd");
    glUniform1f(material_kd_location, materialKd);

    int material_ks_location = glGetUniformLocation(shader->program, "material_ks");
    glUniform1f(material_ks_location, materialKs);

    int object_location = glGetUniformLocation(shader->program, "object_color");
    glUniform3fv(object_location, 1, glm::value_ptr(color));

    // Bind model matrix
    GLint loc_model_matrix = glGetUniformLocation(shader->program, "Model");
    glUniformMatrix4fv(loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

    // Bind view matrix
    glm::mat4 viewMatrix = camera->GetViewMatrix();
    int loc_view_matrix = glGetUniformLocation(shader->program, "View");
    glUniformMatrix4fv(loc_view_matrix, 1, GL_FALSE, glm::value_ptr(viewMatrix));

    // Bind projection matrix
    int loc_projection_matrix = glGetUniformLocation(shader->program, "Projection");
    glUniformMatrix4fv(loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

    // Draw the object
    glBindVertexArray(mesh->GetBuffers()->m_VAO);
    glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_INT, 0);
}

/*
 *  These are callback functions. To find more about callbacks and
 *  how they behave, see `input_controller.h`.
 */


void Tema2::OnInputUpdate(float deltaTime, int mods)
{
    float cameraSpeed = 2.0f;

    if (window->KeyHold(GLFW_KEY_W)) {
        glm::vec3 dir = glm::normalize(glm::vec3(camera->forward.x, 0, camera->forward.z));
        playerX += dir.x * cameraSpeed * deltaTime;
        playerZ += dir.z * cameraSpeed * deltaTime;

        camera1->MoveForward(cameraSpeed * deltaTime);
        camera2->MoveForward(cameraSpeed * deltaTime);
    }

    if (window->KeyHold(GLFW_KEY_S)) {
        glm::vec3 dir = glm::normalize(glm::vec3(camera->forward.x, 0, camera->forward.z));
        playerX -= dir.x * cameraSpeed * deltaTime;
        playerZ -= dir.z * cameraSpeed * deltaTime;

        camera1->MoveForward(-cameraSpeed * deltaTime);
        camera2->MoveForward(-cameraSpeed * deltaTime);
    }

    if (window->KeyHold(GLFW_KEY_A)) {
        playerX -= 2.0f * deltaTime * cos(playerAngleLeftRight);
        playerZ += 2.0f * deltaTime * sin(playerAngleLeftRight);
        camera1->TranslateRight(-cameraSpeed * deltaTime);
        camera2->TranslateRight(-cameraSpeed * deltaTime);
    }

    if (window->KeyHold(GLFW_KEY_D)) {
        playerX += 2.0f * deltaTime * cos(playerAngleLeftRight);
        playerZ -= 2.0f * deltaTime * sin(playerAngleLeftRight);
        camera1->TranslateRight(cameraSpeed * deltaTime);
        camera2->TranslateRight(cameraSpeed * deltaTime);
    }

    // Shoot projectile
    if (window->MouseHold(GLFW_MOUSE_BUTTON_LEFT) && camera == camera1) {
        if (lastShot == 0 || timeSinceStart - lastShot >= 0.5) {
            glm::vec3 dir = glm::normalize(glm::vec3(camera->forward.x, 0, camera->forward.z));

            projectiles.push_back(Projectile(glm::vec3(playerX , playerY + 0.075, playerZ), playerAngleLeftRight, playerAngleUpDown));
            cout << playerX << " " << playerY << " " << playerZ << " " << playerAngleLeftRight << " " << playerAngleUpDown << endl;
            lastShot = timeSinceStart;
        }
    }
}


void Tema2::OnKeyPress(int key, int mods)
{
    // Add key press event
    if (key == GLFW_KEY_T)
    {
        renderCameraTarget = !renderCameraTarget;
    }
    // TODO(student): Switch projections

    if (key == GLFW_KEY_C) {
        if (camera == camera1)
            camera = camera2;
        else
            camera = camera1;
    }

}


void Tema2::OnKeyRelease(int key, int mods)
{
    // Add key release event
}


void Tema2::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
    // Add mouse move event

    if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
    {
        float sensivityOX = 0.001f;
        float sensivityOY = 0.001f;

        camera1->RotateFirstPerson_OX(-sensivityOX * deltaY);
        camera1->RotateFirstPerson_OY(-sensivityOY * deltaX);

        camera2->RotateThirdPerson_OX(-sensivityOX * deltaY);
        camera2->RotateThirdPerson_OY(-sensivityOY * deltaX);

        playerAngleLeftRight -= sensivityOY * deltaX;
        playerAngleUpDown -= sensivityOX * deltaY;
    }
}


void Tema2::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button press event
}


void Tema2::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button release event
}


void Tema2::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}


void Tema2::OnWindowResize(int width, int height)
{
}
