#pragma once

#include "components/simple_scene.h"
#include "lab_m1/tema2/tema2_camera.h"
#include "lab_m1/tema2/projectiles.h"
#include <algorithm>
#include <array>
#include <random>
#include <chrono>
#include <time.h>
#include <queue>

namespace m1
{
    struct Point {
        int row;
        int col;
        int dist;
    };

    class Tema2 : public gfxc::SimpleScene
    {
     public:
         Tema2();
        ~Tema2();

        void Init() override;

     private:
        void FrameStart() override;
        void Update(float deltaTimeSeconds) override;
        void FrameEnd() override;

        void RenderMesh(Mesh *mesh, Shader *shader, const glm::mat4 &modelMatrix) override;
        void RenderSimpleMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, const glm::vec3& color);

        int distanceInLabirinth(int start_row, int start_col, int dest_row, int dest_col) {
            Point start = { start_row, start_col, 0 };

            bool visited[labirinth_rows][labirinth_cols];

            for (int i = 0; i < labirinth_rows; i++) {
                for (int j = 0; j < labirinth_cols; j++) {
                    visited[i][j] = false;
                }
            }

            std::queue<Point> queue;

            queue.push(start);

            while (!queue.empty()) {
                Point current = queue.front();
                queue.pop();

                // Neighbours
                int neigh_row, neigh_col;
                for (int i = 0; i < 4; i++) {
                    // North
                    if (i == 0) {
                        neigh_row = current.row - 1;
                        neigh_col = current.col;
                    }
                    // South
                    else if (i == 1) {
                        neigh_row = current.row + 1;
                        neigh_col = current.col;
                    }
                    // East
                    else if (i == 2) {
                        neigh_row = current.row;
                        neigh_col = current.col + 1;
                    }
                    // West
                    else {
                        neigh_row = current.row;
                        neigh_col = current.col - 1;
                    }

                    // If it is in grid
                    if (neigh_row >= 0 && neigh_row < labirinth_rows && neigh_col >= 0 && neigh_col < labirinth_cols) {
                        // If it is a hallway and wasn't visited
                        if (labirinth[neigh_row][neigh_col] == 0 && visited[neigh_row][neigh_col] == false) {
                            // If it's the destination
                            if (neigh_row == dest_row && neigh_col == dest_col) {
                                return current.dist + 1;
                            }
                            else {
                                visited[neigh_row][neigh_col] = true;
                                Point newPoint = { neigh_row, neigh_col, current.dist + 1 };
                                queue.push(newPoint);
                            }
                        }
                    }
                }
            }

            return -1;
        }

        void backtrackingGenerator(int current_row, int current_col) {
            std::array<Direction, 4> directions = { North, South, East, West };
            unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();

            shuffle(directions.begin(), directions.end(), std::default_random_engine(seed));

            int new_row, new_col;

            for (int i = 0; i < 4; i++) {
                switch (directions[i])
                {
                case North:
                    new_row = current_row - 2;
                    new_col = current_col;
                    break;
                case South:
                    new_row = current_row + 2;
                    new_col = current_col;
                    break;
                case East:
                    new_row = current_row;
                    new_col = current_col + 2;
                    break;
                case West:
                    new_row = current_row;
                    new_col = current_col - 2;
                    break;
                default:
                    break;
                }

                // If the new position is valid (is on the grid)
                if (new_row >= 1 && new_row < labirinth_rows && new_col >= 1 && new_col < labirinth_cols) {
                    // If the new position was not visited
                    if (labirinth_generator_visited[new_row][new_col] == false) {
                        int passage_row = (new_row + current_row) / 2;
                        int passage_col = (new_col + current_col) / 2;

                        labirinth_generator_visited[new_row][new_col] = true;
                        labirinth[passage_row][passage_col] = 0;

                        backtrackingGenerator(new_row, new_col);
                    }
                }
            }
        }

        void generateLabirinth() {
            // Setting initial labirinth
            for (int i = 0; i < labirinth_rows; i++) {
                for (int j = 0; j < labirinth_cols; j++) {
                    if (i % 2 == 0 || j % 2 == 0) {
                        labirinth[i][j] = 1;
                    }
                    else {
                        labirinth[i][j] = 0;
                    }
                }
            }

            // Setting visited matrix
            for (int i = 0; i < labirinth_rows; i++) {
                for (int j = 0; j < labirinth_cols; j++) {
                    if (i % 2 == 1 && j % 2 == 1) {
                        labirinth_generator_visited[i][j] = false;
                    }
                }
            }

            std::random_device rd;
            std::mt19937 gen(rd());
            std::uniform_int_distribution<> startRand(1, (labirinth_rows - 1) / 2);

            starting_pos_row = startRand(gen) * 2 - 1;

            backtrackingGenerator(starting_pos_row, 1);

            labirinth[starting_pos_row][0] = 0;

            int distMax = 0;
            int exit_row;
            int exit_col = labirinth_cols - 2;
            for (int i = 0; i < labirinth_rows; i++) {
                if (labirinth[i][labirinth_cols - 2] == 0) {
                    int distCurrent = distanceInLabirinth(i, labirinth_cols - 2, starting_pos_row, 1);
                    if (distCurrent > distMax) {
                        distMax = distCurrent;
                        exit_row = i;
                    }
                }
            }

            labirinth[exit_row][labirinth_cols - 1] = 0;
        }

        void OnInputUpdate(float deltaTime, int mods) override;
        void OnKeyPress(int key, int mods) override;
        void OnKeyRelease(int key, int mods) override;
        void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
        void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
        void OnWindowResize(int width, int height) override;

     protected:
        implemented::CameraTema2 *camera, *camera1, *camera2;
        glm::mat4 projectionMatrix;
        bool renderCameraTarget;

        float field_of_view;
        int projection_type;
        float playerX, playerY, playerZ;

        float left = -10.0f, right = 10.0f, bottom = -10.0f, top = 10.0f;

        // TODO(student): If you need any other class variables, define them here.

        glm::vec3 lightPosition;
        unsigned int materialShininess;
        float materialKd;
        float materialKs;

        float playerAngleLeftRight;
        float playerAngleUpDown;
        float timeSinceStart;
        float lastShot;

        std::vector<Projectile> projectiles;

        static const int labirinth_rows = 11;
        static const int labirinth_cols = 11;
        int labirinth[labirinth_rows][labirinth_cols];
        bool labirinth_generator_visited[labirinth_rows][labirinth_cols];

        int starting_pos_row;

        enum Direction {North, South, East, West};
    };
}   // namespace m1
